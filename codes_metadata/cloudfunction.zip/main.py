
from google.cloud import storage
import requests
from zipfile import ZipFile
import pandas as pd
from google.cloud import bigquery
import json
import os
from datetime import datetime
import time as td
import pytz
from pytz import timezone
import sys
import shutil

project_id = os.environ.get('GCP_PROJECT')
function_name = os.environ.get('FUNCTION_NAME')
timeoutValue=540

def load_amplitude_api_data_to_bq(event,context):
    try:
        g_start_time = td.time()    
        storage_client = storage.Client(mfrmProjectId)
        client_bq = bigquery.Client(mfrmProjectId)
        print('STAGE 1 | Getting configurations from Big Query against config name AmplitudeEventsExport ')
        query_statement = """SELECT Query FROM `mfrm_config_logging_data.jobs_config_data` WHERE Active = 'True' and ConfigName='AmplitudeEventsExport'"""
        load_job = client_bq.query(query_statement)  
        configurations = load_job.result(timeout=300).to_dataframe()  
        print('Parsing Configurations')
        Query = json.loads(str(configurations.iloc[0][0]))

        source_bucket_name = Query['source_bucket_name']
        destination_bucket_name = Query['destination_bucket_name']
        source_prefix="GCPInbound/SleepAmplitude/"
        destination_prefix="GCPInbound/ProcessedZone/SleepAmplitude/"
        failed_prefix="GCPInbound/FailedZone/SleepAmplitude/"
        list_of_dataframes=[]
        bucket = storage_client.bucket(source_bucket_name)
        blobs_=bucket.list_blobs(prefix=source_prefix)
        print('STAGE 2 | finding zip files')
        
        folders=[]
        for blob in blobs_:
            files=str(blob.name)
            if files.endswith('.zip'):
                blob = bucket.blob(blob.name)
                file=files.split('/')
                file='/tmp/'+file[-1]
                blob.download_to_filename(file)
                folders.append(file)
        
        if len(folders) != 0:
            for folder in folders:
                with ZipFile(folder, 'r') as zip_ref:#
                    zip_ref.extractall('/tmp/overall_data')
            path = '/tmp/overall_data'
            files_=os.listdir(path)
            for files__ in files_:
                files = os.listdir(path+'/'+files__)
                for f in files:
                    #print(path+'/'+files__+'/'+f)
                    df = pd.read_json(path+'/'+files__+'/'+f,lines=True, compression='gzip')
                    list_of_dataframes.append(df)
            
            shutil.rmtree(path)
            merged_df = pd.concat(list_of_dataframes)
            line_delimated_json=merged_df.to_json(orient='records',lines=True)
            splitted_json = line_delimated_json.split('\n')
            df = pd.DataFrame({"JSONObject": splitted_json}) 
            print("Shape of df is {}".format(df.shape))
            
            table_ref=project_id+'.'+'mfrm_staging_dataset.amplitude_api_data_stg'
            job_config = bigquery.LoadJobConfig()
            job_config.autodetect = False
            job_config.ignoreUnknownValues = True
            job_config.write_disposition = bigquery.WriteDisposition.WRITE_TRUNCATE  
            load_job = client_bq.load_table_from_dataframe(df, table_ref, job_config=job_config)
            print('STAGE 3 | loading to bigquery stage')
            load_job.result()
            table = client_bq.get_table(table_ref)
            print("Loaded {} rows and {} columns to {}".format(table.num_rows, len(table.schema),table_ref))
            
            print("STAGE 4 | Invoking Stored procedure to move data from stage to main")
            client_bq = bigquery.Client(mfrmProjectId)
            main_table_sp = """CALL mfrm_customer_and_social.sp_load_amplitude_api_data();"""
            queryJob = client_bq.query(main_table_sp, location="US", timeout=timeoutValue)
            print("Stored Procedure invoked.. Waiting for it to complete")
            rows_table = queryJob.result().to_dataframe()  # Waits for query to finish
            rows = 0
            rowsCount = 0
            
            for job in client_bq.list_jobs(parent_job=queryJob.job_id):
                print("Job ID: {}, Statement Type: {}".format(job.job_id, job.statement_type))
                if job.statement_type == "INSERT":  # print the desired job output only
                    rows = job.num_dml_affected_rows
                    rowsCount = rowsCount + rows
                print("No of rows: {}, Statement Type: {}".format(rowsCount, job.statement_type))

            print("STAGE 5 | Copying files to processed zone")
            copy_files(source_bucket_name,destination_bucket_name,source_prefix, destination_prefix)
            print("STAGE 6 | Removing files from landing zone")
            delete_files(source_prefix,source_bucket_name)  # clearing up the processing zone
            print("Deleted from landing zone")

            g_end_time = td.time()
            print("Data Load took {} seconds".format(g_end_time - g_start_time))
        else:
            print('STAGE 3 | No file in landing zone. Sending Monitoring Email ..')
            email_message = """For {_CurrentDate}, No files found in Mulesoft Bucket at GCPInbound/SleepAmplitude prefix.\n\n""".format(
                            _CurrentDate=datetime.now(pytz.timezone('America/Chicago')).strftime('%Y-%m-%d'))
            SendMonitoringEmail(email_message)
            
            g_end_time = td.time()
            print("Data Load took {} seconds".format(g_end_time - g_start_time))

    except Exception as e:
        print(str(e))
        sendEmail(function_name, str(e))
        
        copy_files(source_bucket_name,destination_bucket_name,source_prefix,destination_prefix.replace(destination_prefix, failed_prefix))  # copying to failed zone
        print("Files Copied to failed zone")

        delete_files(source_prefix,source_bucket_name)  # clearing up the processing zone
        print("Files Deleted from landing zone")


def copy_file(source_bucket_name,destination_bucket_name,source_blob_to_copy, destination_blob):
    storage_client = storage.Client(mfrmProjectId)
    source_bucket = storage_client.get_bucket(source_bucket_name)
    destination_bucket = storage_client.get_bucket(destination_bucket_name)
    source_blob_to_copy = source_bucket.blob(source_blob_to_copy)
    print('source_blob_to_copy {} destination_bucket_name {} destination_blob {} '.format(source_blob_to_copy,destination_bucket_name,destination_blob))
    blob_copy = source_bucket.copy_blob(source_blob_to_copy, destination_bucket, destination_blob)

def copy_files(source_bucket_name,destination_bucket_name,source_prefix_to_copy, dest_prefix):
    try:
        storage_client = storage.Client(mfrmProjectId)
        bucket = storage_client.get_bucket(source_bucket_name)

        for blob in list(storage_client.list_blobs(bucket, prefix=source_prefix_to_copy)):
            source_blob_to_copy = blob.name

            destination_blob_prefix = dest_prefix + str(
                datetime.now(timezone('America/Chicago')).strftime('%Y-%m-%d')) + '/'

            destination_blob = source_blob_to_copy.replace(source_prefix_to_copy, destination_blob_prefix)
            copy_file(source_bucket_name,destination_bucket_name,source_blob_to_copy, destination_blob)       
    except Exception as e:
        print(str(e))
        sendEmail(function_name, str(e))

def sendEmail(function_name, e):
    requestNotification = {
        "notificationType": "Fail",
        "functionName": function_name,
        "errorMessage": 'Error occurred in cloud function "' + function_name + '".  Below is the complete error details found in the logs.',
        "additionalMessage": str(e)
    }
    print("Sending error email ...")
    r = requests.post(
        'https://us-central1-' + mattressFinderProjectId + '.cloudfunctions.net/Send-Email-Notifications',
        json=requestNotification)

#Monitoring email
def SendMonitoringEmail(message):
    _date = datetime.now(pytz.timezone('America/Chicago')).strftime('%Y-%m-%d')
    requestNotification = {
        "notificationType": "Monitoring",
        "projectId": mfrmProjectId,
        "processName": function_name,
        "functionName": function_name,
        "timeStamp": str(_date),
        "additionalMessage": message
    }
    print("Sending notification email ...")
    r = requests.post('https://us-central1-' +mattressFinderProjectId + '.cloudfunctions.net/Send-Email-Notifications',json=requestNotification)

def delete_files(to_be_delete_prefix,source_bucket_name):
    try:
        storage_client = storage.Client(mfrmProjectId)
        print("delete files")
        source_bucket = storage_client.get_bucket(source_bucket_name)
        source_bucket.delete_blobs(
            blobs=source_bucket.list_blobs(prefix=to_be_delete_prefix))  # deleting CDC files from processing zone
    except Exception as e:
        print(str(e))
        sendEmail(function_name, str(e))

def ProjectIds(project_id):
    if project_id == 'mattress-firm-inc' or project_id == 'prod-mattressfinder-project':
        mfrmProjectId = 'mattress-firm-inc'
        mattressFinderProjectId = 'prod-mattressfinder-project'
        return mfrmProjectId, mattressFinderProjectId
    else:
        env = project_id.split('-')[0]
        mfrmProjectId = env + '-mfrm-data'
        mattressFinderProjectId = env + '-mattressfinder-project'
        return mfrmProjectId, mattressFinderProjectId

mfrmProjectId, mattressFinderProjectId = ProjectIds(project_id)